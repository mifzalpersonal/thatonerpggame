# ECB Oracle Offline

**Kategori:** Crypto
**Difficulty:** Hard
**Poin:** 750

## Deskripsi

Kami menemukan sebuah "enkripsi service" lokal: `oracle.py`. Service ini mengenkripsi
string yang kamu berikan, **dikonkatenasi dengan pesan rahasia**, menggunakan AES di
mode yang "populer tapi salah".

```
ciphertext = AES_ECB_Encrypt( your_input || secret_message , key )
```

- `key` random, tidak pernah dibocorkan.
- `secret_message` statis (sama setiap call).
- Kamu boleh memanggil oracle berkali-kali lewat CLI:

```bash
python oracle.py <hex_or_plain_input>
```

Tugas: recover `secret_message` — di dalamnya ada flag.

## Aturan

- Kamu tidak boleh membaca variabel internal oracle dengan patching / debugger. Gunakan
  hanya output ciphertext.
- Key harus tetap random (jangan disentuh). Kamu juga tidak boleh ubah fungsi
  `encrypt`.
- Skrip solver kamu harus bisa menyelesaikan soal dalam < 10 detik di laptop normal.

## Format Flag

`BRKDWN{...}`

## Hints

1. Mode "populer tapi salah" = **ECB**. Blok yang plaintext-nya identik akan ciphertext-nya
   identik. Ini bocor lebih dari kelihatannya.
2. Konsep serangan: **byte-at-a-time ECB decryption**.
3. Untuk setiap byte yang ingin kamu recover, kirim input yang "mendorong" byte tersebut
   ke ujung sebuah blok. Lalu bangun rainbow table sementara untuk menebak byte itu.

## File yang Disediakan

- `oracle.py`       — service enkripsi. Panggil via CLI, dapatkan hex ciphertext.
- `example_run.txt` — contoh output dua call untuk sanity check.
