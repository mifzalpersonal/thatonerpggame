"""Offline simulation of /admin endpoint.

Usage:
    python app.py <jwt_token>

Returns flag if token is valid HS256 and claim role == "admin".
"""
import base64
import hashlib
import hmac
import json
import sys


FLAG = "BRKDWN{jwt_w3ak_s3cr3t_cr4ck3d_hs256_w1n}"
# Secret tidak pernah dicetak. Bukan di file wordlist juga -- peserta harus crack.
_SECRET = "sunshine".encode()


def b64url_dec(s: str) -> bytes:
    pad = "=" * (-len(s) % 4)
    return base64.urlsafe_b64decode(s + pad)


def verify(token: str) -> dict:
    try:
        h_b64, p_b64, s_b64 = token.split(".")
    except ValueError as e:
        raise ValueError("malformed token") from e

    header = json.loads(b64url_dec(h_b64))
    payload = json.loads(b64url_dec(p_b64))
    signature = b64url_dec(s_b64)

    alg = (header.get("alg") or "").upper()
    if alg in ("NONE", ""):
        raise ValueError("alg=none is forbidden")
    if alg != "HS256":
        raise ValueError(f"unsupported alg: {alg}")

    expected = hmac.new(
        _SECRET, f"{h_b64}.{p_b64}".encode(), hashlib.sha256
    ).digest()
    if not hmac.compare_digest(expected, signature):
        raise ValueError("bad signature")
    return payload


def main():
    if len(sys.argv) != 2:
        print("usage: python app.py <token>", file=sys.stderr)
        return 2
    token = sys.argv[1].strip()
    try:
        payload = verify(token)
    except Exception as ex:
        print(f"401 Unauthorized: {ex}")
        return 1

    if payload.get("role") != "admin":
        print("403 Forbidden: admin only")
        return 1

    print(f"200 OK: {FLAG}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
