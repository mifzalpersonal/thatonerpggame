# Broken Token

**Kategori:** Web / Misc (offline simulation)
**Difficulty:** Medium-Hard
**Poin:** 500

## Deskripsi

Sebuah aplikasi web punya fitur login berbasis **JWT**. Developer memberi kami dua file:

- `app.py`     — simulasi handler endpoint `/admin` (versi offline, tidak perlu server).
- `token.txt`  — JWT milik user biasa (`role=user`) yang kami tangkap dari traffic.

Endpoint `/admin` hanya mengembalikan **flag** jika token yang diberikan memiliki klaim
`role=admin` dan lulus verifikasi tanda tangan.

Jalankan:

```bash
python app.py <token>
```

Tugas kamu: buat token yang membuat `app.py` mengembalikan flag.

## Aturan

- **Tidak boleh** modifikasi `app.py`. Kamu hanya bisa menyediakan argumen token.
- Solusinya tidak membutuhkan bruteforce di atas beberapa detik pada laptop biasa.

## Format Flag

`BRKDWN{...}`

## Hints

1. Perhatikan algoritma apa saja yang diterima oleh verifier di `app.py`.
2. Library JWT yang "permisif" punya sejarah yang buruk dengan satu algoritma tertentu.
3. Jika jalur mudah ditutup, masih ada satu jalur: secret HS256 yang dipakai sangat lemah.
   Wordlist kecil `rockyou-mini.txt` disertakan.
