# Pyc Puzzle

**Kategori:** Reversing
**Difficulty:** Medium
**Poin:** 350

## Deskripsi

Kami menemukan file `checker.pyc` yang dipakai program internal untuk memvalidasi lisensi.
Program meminta input flag dari user dan hanya berkata "OK" jika flag benar.

File yang diberikan:
- `checker.pyc` — compiled Python bytecode
- `enc_table.bin` — file biner yang dipakai oleh checker

Tugas: temukan flag yang membuat checker berkata "OK".

## Cara Menjalankan

```bash
python checker.pyc
```

> Catatan: `checker.pyc` dibuat dengan Python **3.12**. Gunakan versi yang sama atau dekat
> untuk menjalankan. Untuk reverse engineering, `uncompyle6` sudah tidak support 3.12,
> tapi `dis` module di standard library selalu jalan.

## Format Flag

`BRKDWN{...}`

## Hints

1. `python -m dis checker.pyc` akan menunjukkan bytecode.
2. `checker.pyc` tidak melakukan network call. Semua logic ada di file lokal.
3. Transform per-byte sederhana, dibantu oleh `enc_table.bin`.
